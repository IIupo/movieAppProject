import React, { useState } from 'react';
import { Alert } from 'antd';
import { SearchBar } from '../components/SearchBar';
import { MovieGrid } from '../components/MovieGrid';
import { MoviePagination } from '../components/MoviePagination';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { ErrorAlert } from '../components/ErrorAlert';
import { useMovieSearch } from '../hooks/useMovieSearch';
import { useSession } from '../context/SessionContext';
import { useRateMovie } from '../hooks/useRateMovie';

export const Search: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const { session } = useSession();
  const { handleRate } = useRateMovie();
  const {
    movies,
    loading,
    error,
    totalResults,
    currentPage,
    handleSearch,
    handlePageChange,
  } = useMovieSearch();

  const onSearch = (query: string) => {
    setSearchQuery(query);
    handleSearch(query);
  };

  return (
    <div>
      <SearchBar onSearch={onSearch} />

      {error && <ErrorAlert message={error} />}

      {loading ? (
        <LoadingSpinner />
      ) : (
        <>
          <MovieGrid
            movies={movies}
            onRate={session ? handleRate : undefined}
          />

          <MoviePagination
            currentPage={currentPage}
            totalResults={totalResults}
            onChange={handlePageChange}
          />

          {!loading && !error && movies.length === 0 && searchQuery && (
            <Alert
              message="No results found"
              type="info"
              showIcon
              className="mb-4"
            />
          )}
        </>
      )}
    </div>
  );
};