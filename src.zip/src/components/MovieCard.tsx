import React from 'react';
import { Card, Tag } from 'antd';
import { useGenres } from '../context/GenreContext';
import { Movie } from '../types/movie';
import { RatingBadge } from './RatingBadge';
import { MovieMeta } from './MovieMeta';

interface MovieCardProps {
  movie: Movie;
  onRate?: (movieId: number, rating: number) => void;
}

export const MovieCard: React.FC<MovieCardProps> = ({ movie, onRate }) => {
  const { genres } = useGenres();
  const posterUrl = movie.poster_path
    ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    : 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&q=80&w=500';

  const movieGenres = genres
    .filter((genre) => movie.genre_ids.includes(genre.id))
    .map((genre) => (
      <Tag key={genre.id} color="blue">
        {genre.name}
      </Tag>
    ));

  return (
    <Card
      cover={
        <img
          alt={movie.title}
          src={posterUrl}
          className="h-64 object-cover"
        />
      }
      className="h-full"
    >
      <RatingBadge rating={movie.vote_average} />
      <MovieMeta
        movie={movie}
        genres={movieGenres}
        onRate={onRate}
      />
    </Card>
  );
};