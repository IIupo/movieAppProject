import React from 'react';
import { Alert } from 'antd';
import { MovieGrid } from '../components/MovieGrid';
import { MoviePagination } from '../components/MoviePagination';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { useRatedMovies } from '../hooks/useRatedMovies';
import { useSession } from '../context/SessionContext';
import { useRateMovie } from '../hooks/useRateMovie';

export const RatedMovies: React.FC = () => {
  const { session } = useSession();
  const { handleRate } = useRateMovie();
  const {
    movies: ratedMovies,
    loading,
    totalResults,
    currentPage,
    handlePageChange,
  } = useRatedMovies();

  if (!session) {
    return (
      <Alert
        message="Session Required"
        description="Please wait while we initialize your session..."
        type="info"
        showIcon
      />
    );
  }

  return (
    <div>

      {loading ? (
        <LoadingSpinner />
      ) : (
        <>
          <MovieGrid
            movies={ratedMovies}
            onRate={handleRate}
          />

          <MoviePagination
            currentPage={currentPage}
            totalResults={totalResults}
            onChange={handlePageChange}
          />

          {(!loading && ratedMovies.length === 0) ? (
            <Alert
              message="No rated movies yet"
              type="info"
              showIcon
            />
          ) : null}
        </>
      )}
    </div>
  );
};