import React from 'react';
import { getRatingColor } from '../utils/ratings';

interface RatingBadgeProps {
  rating: number;
}

export const RatingBadge: React.FC<RatingBadgeProps> = ({ rating }) => (
  <div className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md">
    <div
      className="w-10 h-10 rounded-full flex items-center justify-center"
      style={{
        backgroundColor: getRatingColor(rating),
        color: 'white',
        fontWeight: 'bold',
      }}
    >
      {rating.toFixed(1)}
    </div>
  </div>
);