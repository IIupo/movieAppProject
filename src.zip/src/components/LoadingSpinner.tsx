import React from 'react';
import { Spin } from 'antd';

export const LoadingSpinner: React.FC = () => (
  <div className="flex justify-center py-8">
    <Spin size="large" />
  </div>
);