import React from 'react';
import { MovieCard } from './MovieCard';
import { Movie } from '../types/movie';

interface MovieGridProps {
  movies: Movie[];
  onRate?: (movieId: number, rating: number) => void;
}

export const MovieGrid: React.FC<MovieGridProps> = ({ movies, onRate }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
    {movies.map((movie) => (
      <MovieCard
        key={movie.id}
        movie={movie}
        onRate={onRate}
      />
    ))}
  </div>
);