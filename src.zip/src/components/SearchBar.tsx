import React from 'react';
import { Input } from 'antd';
import { useDebounce } from 'use-debounce';

interface SearchBarProps {
  onSearch: (query: string) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({ onSearch }) => {
  const [debouncedCallback] = useDebounce(
    (value: string) => {
      if (value) {
        onSearch(value);
      }
    },
    500
  );

  return (
    <Input.Search
      placeholder="Search for movies..."
      onChange={(e) => debouncedCallback(e.target.value)}
      className="max-w-2xl mx-auto mb-8"
      size="large"
      allowClear
    />
  );
};