import React from 'react';
import { Card, Rate } from 'antd';
import { Movie } from '../types/movie';

interface MovieMetaProps {
  movie: Movie;
  genres: React.ReactNode;
  onRate?: (movieId: number, rating: number) => void;
}

export const MovieMeta: React.FC<MovieMetaProps> = ({ movie, genres, onRate }) => (
  <Card.Meta
    title={movie.title}
    description={
      <>
        <div className="mb-2">
          {new Date(movie.release_date).toLocaleDateString()}
        </div>
        <div className="mb-2">{genres}</div>
        <p className="line-clamp-3 mb-4">{movie.overview}</p>
        {onRate ? (
          <Rate
            count={10}
            defaultValue={movie.rating}
            onChange={(value) => onRate(movie.id, value)}
          />
        ) : null}
      </>
    }
  />
);