
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from 'antd';
import { Search } from './pages/Search';
import { RatedMovies } from './pages/RatedMovies';
import { GenreProvider } from './context/GenreContext';
import { SessionProvider } from './context/SessionContext';
import { Navigation } from './components/Navigation';

const { Content, Header } = Layout;

function App() {
  return (
    <Router>
      <SessionProvider>
        <GenreProvider>
          <Layout className="min-h-screen">
            <Header className="bg-white shadow-md p-0">
              <Navigation />
            </Header>
            <Content className="p-8">
              <h1 className="text-4xl font-bold text-center mb-8">Movie Database</h1>
              <Routes>
                <Route path="/" element={<Search />} />
                <Route path="/rated" element={<RatedMovies />} />
              </Routes>
            </Content>
          </Layout>
        </GenreProvider>
      </SessionProvider>
    </Router>
  );
}

export default App;