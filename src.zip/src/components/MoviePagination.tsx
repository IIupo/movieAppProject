import React from 'react';
import { Pagination } from 'antd';

interface MoviePaginationProps {
  currentPage: number;
  totalResults: number;
  onChange: (page: number) => void;
}

export const MoviePagination: React.FC<MoviePaginationProps> = ({
  currentPage,
  totalResults,
  onChange,
}) => {
  if (totalResults === 0) return null;

  return (
    <Pagination
      current={currentPage}
      total={totalResults}
      pageSize={20}
      onChange={onChange}
      showSizeChanger={false}
      className="text-center mt-8"
    />
  );
};